package ru.javawebinar.topjava.model;

public enum Role {
    USER,
    ADMIN
}